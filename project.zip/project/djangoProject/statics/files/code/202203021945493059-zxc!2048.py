def main():
    '''
    主函数，在这里进行程序的运行
    :return:
    '''
    l=[-1]*4
    for i in range(4):
        l[i]=[-1]*4
    generate_value(l)
    while True:
        if adw(l): break
        generate_value(l)
        for i in range(4):
            print(l[i])
        q=operation(l)
        if qwe(l):
            if q:
                break
def adw(l):
    for i in range(4):
        for j in range(4):
            if l[i][j]==2048:
                return True
def qwe(l):
    for i in range(4):
        for j in range(4):
            if l[i][j]==-1:
                return False
    return True
def lookup(l):
    '''
    在方形中查找空格
    :param l:
    :return:
    '''
    m=[]
    for i in range(4):
        for j in range(4):
            if l[i][j]==-1:
                s=(i,j)
                m.append(s)
    return m

def generate_value(l):
    '''
    生成随机数2或4，并在4*4方形中的空格插入
    :param l:
    :return:
    '''
    import random
    n=[2,4]
    m=lookup(l)#在方阵中找到没有数占据的位置
    a=random.choice(m)
    l[a[0]][a[1]]=random.choice(n)

def operation(l):
    '''
    操作平台，选取四个方向
    :param l:
    :return:
    '''
    q={'w':'上','s':'下','a':'左','d':'右'}
    a=input(f"{q}，请输入你的选择：")
    if a=='w':
        return upward_sum(l)
    elif a=='s':
        return down_sum(l)
    elif a=='a':
        return left_sum(l)
    elif a=='d':
        return right_sum(l)
    else:
        print("输入错误，重新输入")
def upward_sum(l):
    '''
    进行向上的相加，并排列
    :param l:
    :return:
    '''
    k=True
    for i in range(4):  # 列
        j = 0
        a = j
        while True:
            if j > 2:
                break
            if l[j][i] != -1 and (l[j+1][i] == -1 or l[j+1][i] == l[j][i]):
                if a > 2:
                    break
                if l[a+1][i] != l[j][i] and l[a+1][i] != -1:
                    j += 1
                    continue
                if l[a+1][i] == l[j][i]:
                    l[j][i], l[a+1][i] = l[j][i] + l[a+1][i], -1
                    k=False
                    j,a = a+2, a+1
                a += 1
            else:
                j,a = j+1, j+1
    arrange_up(l)
    if k:
        return k
def arrange_up(l):
    '''
    向上排列
    :param l:
    :return:
    '''
    for i in range(4):  # 列
        j = 0
        a = j
        while True:
            if j > 2:
                break
            if l[j][i] == -1:
                if a > 2: break
                if l[a+1][i] != -1:
                    l[j][i], l[a+1][i] = l[a+1][i], -1
                    j = j + 1
                    a = j
                else:
                    a += 1
            else:
                j += 1
                a=j
def down_sum(l):
    '''
    向下求和，并排列
    :param l:
    :return:
    '''
    k=True
    for i in range(4):
        j = 3
        a = j
        while True:
            if j < 1:
                break
            if l[j][i] != -1 and (l[j-1][i] == -1 or l[j-1][i] == l[j][i]):
                if a < 1:
                    break
                if l[a-1][i]!=l[j][i] and l[a-1][i]!=-1:
                    j-=1
                    continue
                if l[a-1][i] == l[j][i]:
                    l[j][i], l[a-1][i] = l[j][i] + l[a-1][i], -1
                    k=False
                    j, a = a-2, a-1
                a -= 1
            else:
                j, a = j-1, j-1
    arrange_down(l)
    if k:
        return k
def arrange_down(l):
    '''
    向下排列
    :param l:
    :return:
    '''
    for i in range(4):  # 列
        j = 3
        a = j
        while True:
            if j < 1:
                break
            if l[j][i] == -1:
                if a < 1: break
                if l[a-1][i] != -1:
                    l[j][i], l[a-1][i] = l[a-1][i], -1
                    j = j - 1
                    a = j
                else:
                    a -= 1
            else:
                j -= 1
                a = j
def left_sum(l):
    '''
    向左求和，排列
    :param l:
    :return:
    '''
    k=True
    for i in range(4):  # 行
        j = 0
        a = j
        while True:
            if j > 2:
                break
            if l[i][j] != -1 and (l[i][j + 1] == -1 or l[i][j + 1] == l[i][j]):
                if a > 2:
                    break
                if l[i][a + 1] != l[i][j] and l[i][a + 1] != -1:
                    j += 1
                    continue
                if l[i][a + 1] == l[i][j]:
                    l[i][j], l[i][a + 1] = l[i][j] + l[i][a + 1], -1
                    k=False
                    j, a = a + 2, a + 1
                a += 1
            else:
                j, a = j + 1, j + 1
    arrange_left(l)
    if k:
        return k
def arrange_left(l):
    '''
    向左排列
    :param l:
    :return:
    '''
    for i in range(4):  # 列
        j = 0
        a = j
        while True:
            if j > 2:
                break
            if l[i][j] == -1:
                if a > 2: break
                if l[i][a + 1] != -1:
                    l[i][j], l[i][a + 1] = l[i][a + 1], -1
                    j = j + 1
                    a = j
                else:
                    a += 1
            else:
                j += 1
                a = j
def right_sum(l):
    '''
    向右求和，排列
    :param l:
    :return:
    '''
    k=True
    for i in range(4):  # 行
        j = 3
        a = j
        while True:
            if j < 1:
                break
            if l[i][j] != -1 and (l[i][j - 1] == -1 or l[i][j - 1] == l[i][j]):
                if a < 1:
                    break
                if l[i][a - 1] != l[i][j] and l[i][a - 1] != -1:
                    j -= 1
                    continue
                if l[i][a - 1] == l[i][j]:
                    l[i][j], l[i][a - 1] = l[i][j] + l[i][a - 1], -1
                    k=False
                    j, a = a - 2, a - 1
                a -= 1
            else:
                j, a = j - 1, j - 1
    arrange_right(l)
    if k:
        return k
def arrange_right(l):
    '''
    向右排列
    :param l:
    :return:
    '''
    for i in range(4):  # 行
        j = 3
        a = j
        while True:
            if j < 1:
                break
            if l[i][j] == -1:
                if a < 1: break
                if l[i][a - 1] != -1:
                    l[i][j], l[i][a - 1] = l[i][a - 1], -1
                    j = j - 1
                    a = j
                else:
                    a -= 1
            else:
                j -= 1
                a = j

if __name__ == '__main__':
    main()