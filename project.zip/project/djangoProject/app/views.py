import os
import datetime
import random

from django.conf import settings
from django.http import HttpResponse, FileResponse
from django.shortcuts import render, redirect
from django.utils.encoding import escape_uri_path

from .models import user
import json


# Create your views here.
def login(req):
    if req.method=='GET':
        return render(req,'app/login.html')
    elif req.method=='POST':
        username=req.POST['username']
        num=user.objects.filter(username__exact=username).count()
        data = {
            'code': 2,
            'message': '登录成功'
        }
        if not num:
            data={
                'code':0,
                'message':'用户名不存在'
            }
        else:
            password=req.POST['password']
            uname=user.objects.get(username__exact=username)
            if uname.password != password:
                data = {
                    'code': 1,
                    'message': '密码错误'
                }

        jsonstr=json.dumps(data)
        resp = HttpResponse(jsonstr)
        resp['content-type'] = 'application/json;charset=utf-8'
        if data['code']==2:
            resp.set_cookie('user',username)
        return resp

def register(req):
    if req.method=='GET':
        return render(req,'app/register.html')
    elif req.method=='POST':
        uname=req.POST['username']
        num=user.objects.filter(username__exact=uname).count()
        data = {
            'code': 1,
            'message': '注册成功'
        }
        if num:
            data = {
                'code': 0,
                'message': '该账号已存在'
            }
        else:
            pas=req.POST['password']
            user.objects.create(username=uname,password=pas)
        jsonstr = json.dumps(data)
        resp = HttpResponse(jsonstr)
        resp['content-type'] = 'application/json;charset=utf-8'
        return resp


def upload(req):
    if req.method=='GET':
        return render(req, 'app/upload.html')
    elif req.method=='POST':
        text=req.POST['text']
        cap=req.POST['cap']
        user=req.POST['user']
        if not user:
            user='佚名'
        text=text+'\n\n\n'+f'作者：{user}'
        text = text.encode()
        files = os.listdir(settings.MEDIA_ROOT+'/article/')
        cap='id'+str(len(files)+1)+'-'+str(datetime.datetime.now().strftime('%Y%m%d%H%M%S'))+\
            str(random.randint(1000,10000))+'_'+\
            cap+'.txt'
        file = os.path.join(settings.MEDIA_ROOT+'/article/',cap)
        with open(file,'wb') as f:
            f.write(text)
            f.close()
        return redirect('app:main')

def download_file(req):
    files = os.listdir(settings.MEDIA_ROOT+'/article/')
    data = []
    for i in files:
        pic={}

        with open(os.path.join(settings.MEDIA_ROOT+'/article/',i), 'r',encoding='UTF-8') as f:  # 打开文件
            lines = f.readlines()  # 读取所有行
            last_line = lines[-1]  # 取最后一行
            pic['autor']=last_line
            f.close()
        pic['id']=i[2:i.find('-')]
        pic['title'] =i[i.find('_')+1:len(i)-4]
        pic['content'] = ''
        for line in open(os.path.join(settings.MEDIA_ROOT+'/article/',i),'r',encoding='UTF-8'):
            pic['content']+=line
            if len(pic['content'])>100:
                pic['content']=pic['content'][0:100]
                data.append(pic)
                break
    return data

def main(req):
    name=req.COOKIES.get('user','')
    if not name:
        return render(req,'app/login.html')
    text=download_file(req)
    music=down_music(req)
    code=xcode(req)
    return render(req,'app/main.html',{
        'text':text,
        'music':music,
        'code':code,
    })

def person(req):
    name=req.COOKIES['user']
    data=user.objects.get(username__exact=name)
    del data.__dict__['_state']

    return render(req,'app/person.html',
                  {
                    'state':data,   #记得改回data.__dict__
                    'list': ['账号', '密码', '姓名', '所在学校', '兴趣爱好']
                   })

def exit(req):
    data=redirect('app:main')
    data.delete_cookie('user')
    return data

def modify(req):
    usere = req.COOKIES.get('user', '')
    username=req.POST['username']
    password=req.POST['password']
    name=req.POST['name']
    school=req.POST['school']
    hobby=req.POST['hobby']
    user.objects.filter(username=usere).update(
        username=username,
        password=password,
        name=name,
        school=school,
        hobby=hobby
    )
    resp=redirect('app:person')
    resp.set_cookie('user',username)
    return resp

def books(req):
    id=req.GET['id']
    files = os.listdir(settings.MEDIA_ROOT+'/article/')
    book = {}
    for file in files:
        nu=file[2:file.find('-')]
        if nu==id:
            book['title']=file[file.find('_')+1:len(file)-4]
            with open(os.path.join(settings.MEDIA_ROOT+'/article/', file), 'r', encoding='UTF-8') as f:  # 打开文件
                lines = f.readlines()  # 读取所有行
                last_line = lines[-1]  # 取最后一行
                book['autor'] = last_line
                book['content']=lines[:-1]
                f.close()
    return render(req,'app/books.html',{'book':book})



def music_up(req):
    if req.method=='GET':
        return render(req,'app/music_up.html')
    elif req.method=='POST':
        file=req.FILES['music']
        filename = os.path.join(settings.MEDIA_ROOT + '/music/', file.name)
        with open(filename, 'wb') as f:
            f.write(file.file.read())
        return redirect('app:main')

def down_music(req):
    files = os.listdir(settings.MEDIA_ROOT+'/music/')
    data = []
    for i in files:
        pic = {}
        mus=i[::-1]
        index=mus.find('.')
        mus=mus[index+1::]
        mus=mus[::-1]
        pic['name'] = mus
        pic['img'] = '/static/files' + os.path.join(settings.MEDIA_ROOT+'/music/', i)
        data.append(pic)
    return data

def dow_code(req):
    file = req.GET['name']
    filename = os.path.join(settings.MEDIA_ROOT+'/code/', file)
    fb = open(filename, 'rb')
    resp = FileResponse(fb)
    resp['Content-Type'] = 'application/octet-stream'
    # resp['Content-Disposition']="attachment;filename*=UTF-8''{}".format(escape_uri_path(file))
    resp['Content-Disposition'] = f"attachment;filename*=UTF-8''{escape_uri_path(file)}"
    return resp

def upload_code(req):
    if req.method=='GET':
        return render(req,'app/upload_code.html')
    elif req.method=='POST':
        name=req.POST['name']
        if not name:
            name='佚名'
        file=req.FILES['file']
        file.name = \
            str(datetime.datetime.now().strftime('%Y%m%d%H%M%S')) + \
            str(random.randint(1000, 10000)) +'-'+ \
            name+'!'+file.name
        filename = os.path.join(settings.MEDIA_ROOT+'/code/', file.name)
        with open(filename, 'wb') as f:
            f.write(file.file.read())
        return redirect('app:main')

def xcode(req):
    files = os.listdir(settings.MEDIA_ROOT + '/code/')
    data=[]
    for file in files:
        book = {}
        index=file.find('-')
        ind=file.find('!')
        book['autor']=file[index+1:file.find('!',index,-1)]
        book['title']=file[ind+1::]
        book['name']=file
        data.append(book)
    return data