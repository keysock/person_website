from django.urls import path
from . import views

app_name='app'

urlpatterns = [
    path('login/',views.login,name='login'),
    path('upload/',views.upload,name='upload'),
    path('register/',views.register,name='register'),
    path('',views.main,name='main'),
    path('person/',views.person,name='person'),
    path('exit/',views.exit,name='exit'),
    path('modify/',views.modify,name='modify'),
    path('download_file/',views.download_file,name='download_file'),
    path('books/',views.books,name='books'),
    path('music_up/',views.music_up,name='music_up'),
    path('down_music/',views.down_music,name='down_music'),
    path('upload_code/',views.upload_code,name='upload_code'),
    path('dow_code/',views.dow_code,name='dow_code')
]